import { useTranslation } from 'react-i18next';

export interface LoadingProps {
    fullScreen?: boolean;
    text?: string | null;
}

export const Loading = ({ fullScreen = false, text }: LoadingProps) => {
    const { t } = useTranslation();
    const displayText = text ?? t('common.loading');
    const content = (
        <div className="flex flex-col items-center justify-center gap-3">
            <svg className="animate-spin h-8 w-8 text-blue-600" viewBox="0 0 24 24" aria-hidden="true">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            {displayText && <span className="text-gray-600 font-medium">{displayText}</span>}
        </div>
    );

    if (fullScreen) {
        return (
            <div className="fixed inset-0 bg-white/80 backdrop-blur-sm z-50 flex items-center justify-center">
                {content}
            </div>
        );
    }

    return <div className="p-8 flex items-center justify-center min-h-[200px]">{content}</div>;
};

export default Loading;
